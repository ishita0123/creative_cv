import React from 'react';
import { motion } from 'framer-motion';
import { User, Heart, Coffee, Code, Globe, Sparkles, Camera, Music } from 'lucide-react';

const About: React.FC = () => {
  const interests = [
    { icon: Code, label: 'Coding', color: 'text-blue-500', bgColor: 'bg-blue-100' },
    { icon: Globe, label: 'Traveling', color: 'text-green-500', bgColor: 'bg-green-100' },
    { icon: Coffee, label: 'Coffee', color: 'text-yellow-600', bgColor: 'bg-yellow-100' },
    { icon: Heart, label: 'Design', color: 'text-red-500', bgColor: 'bg-red-100' },
    { icon: Camera, label: 'Photography', color: 'text-purple-500', bgColor: 'bg-purple-100' },
    { icon: Music, label: 'Music', color: 'text-pink-500', bgColor: 'bg-pink-100' },
  ];

  const stats = [
    { number: '3+', label: 'Years Experience', color: 'from-blue-500 to-cyan-500' },
    { number: '50+', label: 'Projects Completed', color: 'from-green-500 to-emerald-500' },
    { number: '15+', label: 'Countries Visited', color: 'from-purple-500 to-pink-500' },
    { number: '∞', label: 'Cups of Coffee', color: 'from-orange-500 to-red-500' },
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-cyan-50 via-blue-50 to-purple-50 relative overflow-hidden">
      {/* Enhanced Background Decoration */}
      <div className="absolute inset-0">
        {/* Animated Gradient Orbs */}
        <motion.div 
          className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-300 to-purple-400 rounded-full opacity-20"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
            x: [0, 50, 0],
            y: [0, -30, 0],
          }}
          transition={{ duration: 20, repeat: Infinity }}
        />
        <motion.div 
          className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-blue-300 to-cyan-400 rounded-full opacity-20"
          animate={{
            scale: [1, 1.3, 1],
            rotate: [360, 180, 0],
            x: [0, -40, 0],
            y: [0, 20, 0],
          }}
          transition={{ duration: 25, repeat: Infinity }}
        />
        
        {/* Floating Sparkles */}
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 360],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <Sparkles className="w-6 h-6 text-yellow-400" />
          </motion.div>
        ))}
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div 
            className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-sky-500 to-purple-500 text-white rounded-full mb-6 shadow-2xl"
            whileHover={{ 
              scale: 1.2, 
              rotate: 360,
              boxShadow: "0 0 30px rgba(14, 165, 233, 0.5)"
            }}
            transition={{ duration: 0.6 }}
          >
            <User className="w-10 h-10" />
          </motion.div>
          
          <motion.h2 
            className="text-5xl md:text-6xl font-bold text-gray-800 mb-6"
            initial={{ opacity: 0, scale: 0.5 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            First Stop: <span className="bg-gradient-to-r from-sky-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">About Me</span>
          </motion.h2>
          
          <motion.p 
            className="text-2xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Welcome to my world! Let me share my story and what drives my passion for technology.
          </motion.p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-20 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              <motion.div
                className="w-96 h-96 mx-auto lg:mx-0 bg-gradient-to-br from-sky-400 via-purple-500 to-pink-500 rounded-3xl shadow-2xl overflow-hidden relative"
                whileHover={{ 
                  scale: 1.05, 
                  rotate: 3,
                  boxShadow: "0 25px 50px rgba(0,0,0,0.3)"
                }}
                transition={{ duration: 0.4 }}
              >
                <motion.div 
                  className="absolute inset-4 bg-white/10 rounded-2xl backdrop-blur-sm flex items-center justify-center border border-white/20"
                  animate={{
                    background: [
                      "rgba(255,255,255,0.1)",
                      "rgba(255,255,255,0.2)",
                      "rgba(255,255,255,0.1)"
                    ]
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <div className="text-center text-white">
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <User className="w-32 h-32 mx-auto mb-6 opacity-80" />
                    </motion.div>
                    <p className="text-2xl font-semibold mb-2">Your Photo Here</p>
                    <p className="text-lg opacity-80">Add your professional photo</p>
                  </div>
                </motion.div>
                
                {/* Animated Border */}
                <motion.div
                  className="absolute inset-0 rounded-3xl"
                  style={{
                    background: "linear-gradient(45deg, transparent, rgba(255,255,255,0.3), transparent)",
                  }}
                  animate={{ rotate: 360 }}
                  transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                />
              </motion.div>
              
              {/* Enhanced Floating Elements */}
              {interests.map((interest, index) => (
                <motion.div
                  key={interest.label}
                  className={`absolute w-16 h-16 ${interest.bgColor} rounded-full shadow-xl flex items-center justify-center border-2 border-white`}
                  style={{
                    top: `${15 + (index * 12)}%`,
                    right: index % 2 === 0 ? '-8%' : 'auto',
                    left: index % 2 === 1 ? '-8%' : 'auto',
                  }}
                  animate={{
                    y: [0, -15, 0],
                    rotate: [0, 15, -15, 0],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    delay: index * 0.3,
                  }}
                  whileHover={{ 
                    scale: 1.3, 
                    rotate: 180,
                    boxShadow: "0 10px 25px rgba(0,0,0,0.2)"
                  }}
                >
                  <interest.icon className={`w-8 h-8 ${interest.color}`} />
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <motion.h3 
                className="text-3xl font-bold text-gray-800 mb-6"
                whileHover={{ scale: 1.05, color: "#8b5cf6" }}
              >
                My Story
              </motion.h3>
              
              <motion.div className="space-y-6 text-gray-600 leading-relaxed text-lg">
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  viewport={{ once: true }}
                >
                  I'm a passionate full-stack developer with a love for creating innovative digital experiences. 
                  My journey began with curiosity about how things work behind the screen, and it evolved into 
                  a deep appreciation for clean code, user experience, and solving complex problems.
                </motion.p>
                
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                  viewport={{ once: true }}
                >
                  When I'm not coding, you'll find me exploring new destinations, capturing moments through 
                  photography, or experimenting with new technologies. I believe that travel broadens the mind 
                  and brings fresh perspectives to problem-solving.
                </motion.p>
                
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1 }}
                  viewport={{ once: true }}
                >
                  I'm always excited to collaborate on projects that make a positive impact and push the 
                  boundaries of what's possible with technology.
                </motion.p>
              </motion.div>
            </div>

            <div>
              <motion.h4 
                className="text-2xl font-semibold text-gray-800 mb-6"
                whileHover={{ scale: 1.05, color: "#06b6d4" }}
              >
                What I Love
              </motion.h4>
              <div className="grid grid-cols-2 gap-4">
                {interests.map((interest, index) => (
                  <motion.div
                    key={interest.label}
                    className={`flex items-center space-x-4 p-4 ${interest.bgColor} rounded-xl shadow-lg border border-white/50`}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{ 
                      scale: 1.08, 
                      y: -5,
                      boxShadow: "0 15px 30px rgba(0,0,0,0.15)"
                    }}
                  >
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                    >
                      <interest.icon className={`w-6 h-6 ${interest.color}`} />
                    </motion.div>
                    <span className="text-gray-700 font-medium">{interest.label}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Enhanced Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                className="text-center p-8 bg-white rounded-2xl shadow-xl border border-gray-100 relative overflow-hidden"
                initial={{ opacity: 0, y: 50, scale: 0.8 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ 
                  scale: 1.1, 
                  y: -10,
                  boxShadow: "0 20px 40px rgba(0,0,0,0.15)"
                }}
              >
                {/* Animated Background Gradient */}
                <motion.div
                  className={`absolute inset-0 bg-gradient-to-r ${stat.color} opacity-0`}
                  whileHover={{ opacity: 0.1 }}
                  transition={{ duration: 0.3 }}
                />
                
                <motion.div
                  className={`text-5xl md:text-6xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-4`}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ 
                    type: "spring", 
                    stiffness: 200, 
                    delay: 0.8 + (index * 0.1) 
                  }}
                  viewport={{ once: true }}
                  animate={{ 
                    scale: [1, 1.1, 1],
                  }}
                  whileHover={{ scale: 1.2 }}
                >
                  {stat.number}
                </motion.div>
                
                <motion.p 
                  className="text-gray-600 font-semibold text-lg"
                  whileHover={{ color: "#374151" }}
                >
                  {stat.label}
                </motion.p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;