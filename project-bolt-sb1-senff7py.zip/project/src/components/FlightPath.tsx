import React from 'react';
import { motion } from 'framer-motion';
import { Plane, MapPin } from 'lucide-react';

interface FlightPathProps {
  activeSection: string;
}

const FlightPath: React.FC<FlightPathProps> = ({ activeSection }) => {
  const sections = ['hero', 'about', 'experience', 'skills', 'projects', 'education', 'contact'];
  const activeIndex = sections.indexOf(activeSection);
  
  const sectionColors = [
    'from-purple-500 to-pink-500',
    'from-blue-500 to-cyan-500', 
    'from-green-500 to-emerald-500',
    'from-yellow-500 to-orange-500',
    'from-purple-500 to-indigo-500',
    'from-pink-500 to-rose-500',
    'from-cyan-500 to-blue-500'
  ];
  
  return (
    <div className="fixed right-8 top-1/2 transform -translate-y-1/2 z-40 hidden lg:block">
      <div className="relative">
        {/* Enhanced Flight Path Line */}
        <svg
          width="6"
          height="450"
          className="absolute left-1/2 transform -translate-x-1/2"
        >
          <defs>
            <linearGradient id="pathGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#8B5CF6" />
              <stop offset="25%" stopColor="#06B6D4" />
              <stop offset="50%" stopColor="#10B981" />
              <stop offset="75%" stopColor="#F59E0B" />
              <stop offset="100%" stopColor="#EF4444" />
            </linearGradient>
            
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          <motion.line
            x1="3"
            y1="0"
            x2="3"
            y2="450"
            stroke="url(#pathGradient)"
            strokeWidth="3"
            strokeDasharray="8,4"
            filter="url(#glow)"
            animate={{
              strokeDashoffset: [0, -24],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "linear"
            }}
          />
        </svg>

        {/* Section Markers */}
        {sections.map((section, index) => (
          <motion.div
            key={section}
            className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2"
            style={{ top: `${(index * 65) + 30}px` }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.2, type: "spring", stiffness: 200 }}
          >
            <motion.div
              className={`relative w-6 h-6 rounded-full border-3 transition-all duration-500 ${
                index <= activeIndex
                  ? `bg-gradient-to-r ${sectionColors[index]} border-white shadow-lg`
                  : 'bg-white border-gray-300'
              }`}
              whileHover={{ scale: 1.5 }}
              animate={index <= activeIndex ? {
                boxShadow: [
                  "0 0 0 0 rgba(139, 92, 246, 0.7)",
                  "0 0 0 10px rgba(139, 92, 246, 0)",
                  "0 0 0 0 rgba(139, 92, 246, 0)"
                ]
              } : {}}
              transition={{ duration: 2, repeat: Infinity }}
            >
              {/* Active Section Indicator */}
              {index === activeIndex && (
                <motion.div
                  className="absolute inset-0 -m-4 flex items-center justify-center"
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <motion.div
                    className={`p-2 bg-gradient-to-r ${sectionColors[index]} rounded-full shadow-xl`}
                    animate={{ 
                      rotate: 360,
                      scale: [1, 1.2, 1]
                    }}
                    transition={{ 
                      rotate: { duration: 4, repeat: Infinity, ease: "linear" },
                      scale: { duration: 2, repeat: Infinity }
                    }}
                  >
                    <Plane className="w-6 h-6 text-white" />
                  </motion.div>
                </motion.div>
              )}
              
              {/* Completed Section Checkmark */}
              {index < activeIndex && (
                <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </motion.div>
              )}
            </motion.div>

            {/* Section Labels */}
            <motion.div
              className={`absolute left-8 top-1/2 transform -translate-y-1/2 px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                index === activeIndex
                  ? `bg-gradient-to-r ${sectionColors[index]} text-white shadow-lg`
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 + 0.5 }}
              whileHover={{ scale: 1.05, x: 5 }}
            >
              {section.charAt(0).toUpperCase() + section.slice(1)}
            </motion.div>
          </motion.div>
        ))}

        {/* Progress Indicator */}
        <motion.div
          className="absolute -left-16 top-0 bg-white rounded-lg shadow-lg p-3 border border-gray-200"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1 }}
        >
          <div className="text-center">
            <motion.div 
              className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              {Math.round(((activeIndex + 1) / sections.length) * 100)}%
            </motion.div>
            <div className="text-xs text-gray-500 font-medium">Journey</div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default FlightPath;