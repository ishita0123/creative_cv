import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, MapPin, Plane, Star, Cloud, Sun } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 via-orange-400 to-yellow-400 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        {/* Floating Clouds */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={`cloud-${i}`}
            className="absolute"
            style={{
              left: `${Math.random() * 120 - 10}%`,
              top: `${Math.random() * 80 + 10}%`,
            }}
            animate={{
              x: [0, 100, 0],
              y: [0, -20, 0],
            }}
            transition={{
              duration: 15 + Math.random() * 10,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          >
            <Cloud className="w-16 h-16 text-white/20" />
          </motion.div>
        ))}

        {/* Twinkling Stars */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={`star-${i}`}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              scale: [0, 1, 0],
              rotate: [0, 180, 360],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
          >
            <Star className="w-4 h-4 text-yellow-200" fill="currentColor" />
          </motion.div>
        ))}

        {/* Floating Geometric Shapes */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={`shape-${i}`}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              rotate: [0, 360],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 6 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <div className={`w-6 h-6 ${i % 3 === 0 ? 'bg-white/20 rounded-full' : i % 3 === 1 ? 'bg-yellow-300/30 rotate-45' : 'bg-pink-300/30 rounded-full'}`} />
          </motion.div>
        ))}
      </div>

      <div className="relative z-10 container mx-auto px-6 py-20 flex flex-col justify-center min-h-screen">
        <div className="text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, type: "spring", bounce: 0.4 }}
            className="mb-8"
          >
            <motion.div
              className="inline-block p-6 bg-gradient-to-r from-white/20 to-white/10 rounded-full mb-8 backdrop-blur-sm border border-white/30"
              animate={{ 
                rotate: [0, 10, -10, 0],
                scale: [1, 1.1, 1],
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              whileHover={{ scale: 1.2, rotate: 15 }}
            >
              <Plane className="w-16 h-16" />
            </motion.div>
            
            <motion.h1 
              className="text-6xl md:text-8xl font-bold mb-6"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              Welcome to My
              <motion.span
                className="block bg-gradient-to-r from-yellow-300 via-pink-300 to-purple-300 bg-clip-text text-transparent"
                initial={{ opacity: 0, x: -200 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1, duration: 1, type: "spring" }}
                whileHover={{ scale: 1.05 }}
              >
                Professional Journey
              </motion.span>
            </motion.h1>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 0.8 }}
            className="mb-8"
          >
            <motion.p 
              className="text-2xl md:text-3xl mb-4 font-light"
              animate={{ 
                textShadow: [
                  "0 0 10px rgba(255,255,255,0.5)",
                  "0 0 20px rgba(255,255,255,0.8)",
                  "0 0 10px rgba(255,255,255,0.5)"
                ]
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              Your Name
            </motion.p>
            <motion.p 
              className="text-xl md:text-2xl opacity-90 max-w-3xl mx-auto mb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2, duration: 1 }}
            >
              Full Stack Developer • Creative Problem Solver • Travel Enthusiast
            </motion.p>
            <motion.p 
              className="text-lg opacity-80 max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2.5, duration: 1 }}
            >
              Embark on an interactive journey through my professional experience, 
              skills, and projects. Each stop reveals a new chapter of my story.
            </motion.p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 3, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12"
          >
            <motion.button
              className="group px-10 py-5 bg-gradient-to-r from-white to-yellow-100 text-purple-600 rounded-full font-bold text-xl shadow-2xl relative overflow-hidden"
              whileHover={{ 
                scale: 1.1, 
                y: -5,
                boxShadow: "0 20px 40px rgba(0,0,0,0.3)"
              }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-pink-400 to-purple-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                initial={false}
              />
              <span className="relative z-10 group-hover:text-white transition-colors duration-300">
                🚀 Start Journey
              </span>
            </motion.button>
            
            <motion.button
              className="group px-10 py-5 border-3 border-white text-white rounded-full font-bold text-xl hover:bg-white hover:text-purple-600 transition-all duration-300 relative overflow-hidden"
              whileHover={{ 
                scale: 1.1, 
                y: -5,
                borderColor: "#fbbf24"
              }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-500 opacity-0 group-hover:opacity-20 transition-opacity duration-300"
                initial={false}
              />
              <span className="relative z-10">📄 Download CV</span>
            </motion.button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 3.5, duration: 0.8 }}
            className="flex flex-wrap items-center justify-center gap-8 text-lg opacity-90"
          >
            <motion.div 
              className="flex items-center space-x-3 bg-white/10 px-6 py-3 rounded-full backdrop-blur-sm"
              whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.2)" }}
            >
              <MapPin className="w-6 h-6 text-yellow-300" />
              <span>Based in Your City</span>
            </motion.div>
            <motion.div 
              className="flex items-center space-x-3 bg-white/10 px-6 py-3 rounded-full backdrop-blur-sm"
              whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.2)" }}
            >
              <motion.div 
                className="w-3 h-3 bg-green-400 rounded-full"
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <span>Available for opportunities</span>
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          animate={{ 
            y: [0, 15, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <motion.div
            className="p-4 bg-white/20 rounded-full backdrop-blur-sm"
            whileHover={{ scale: 1.2, backgroundColor: "rgba(255,255,255,0.3)" }}
          >
            <ArrowDown className="w-8 h-8 text-white" />
          </motion.div>
        </motion.div>
      </div>

      {/* Animated Sun */}
      <motion.div
        className="absolute top-10 right-10"
        animate={{
          rotate: 360,
          scale: [1, 1.1, 1],
        }}
        transition={{
          rotate: { duration: 20, repeat: Infinity, ease: "linear" },
          scale: { duration: 4, repeat: Infinity }
        }}
      >
        <Sun className="w-16 h-16 text-yellow-300" />
      </motion.div>
    </section>
  );
};

export default Hero;