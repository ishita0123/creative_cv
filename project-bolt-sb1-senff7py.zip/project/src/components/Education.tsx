import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Award, BookOpen, Users } from 'lucide-react';

const Education: React.FC = () => {
  const education = [
    {
      degree: 'Master of Science in Computer Science',
      school: 'University of Technology',
      location: 'San Francisco, CA',
      period: '2017 - 2019',
      description: 'Specialized in Software Engineering and Machine Learning. Graduated Magna Cum Laude with a focus on distributed systems and AI.',
      achievements: [
        'GPA: 3.8/4.0',
        'Dean\'s List (4 semesters)',
        'Outstanding Graduate Student Award',
        'Published 2 research papers'
      ],
      color: 'from-blue-500 to-purple-500'
    },
    {
      degree: 'Bachelor of Science in Software Engineering',
      school: 'State University',
      location: 'Austin, TX',
      period: '2013 - 2017',
      description: 'Comprehensive education in software development, algorithms, and system design. Active in student organizations and hackathons.',
      achievements: [
        'GPA: 3.7/4.0',
        'Summa Cum Laude',
        'Computer Science Society President',
        'Winner of 3 hackathons'
      ],
      color: 'from-green-500 to-teal-500'
    }
  ];

  const certifications = [
    {
      title: 'AWS Solutions Architect',
      issuer: 'Amazon Web Services',
      date: '2023',
      credentialId: 'AWS-SAA-12345',
      color: 'bg-orange-500'
    },
    {
      title: 'Google Cloud Professional',
      issuer: 'Google Cloud',
      date: '2022',
      credentialId: 'GCP-PCA-67890',
      color: 'bg-blue-500'
    },
    {
      title: 'React Developer Certification',
      issuer: 'Meta',
      date: '2022',
      credentialId: 'META-RDC-11111',
      color: 'bg-cyan-500'
    },
    {
      title: 'Kubernetes Administrator',
      issuer: 'Cloud Native Computing Foundation',
      date: '2021',
      credentialId: 'CNCF-CKA-22222',
      color: 'bg-purple-500'
    }
  ];

  const additionalLearning = [
    {
      title: 'Full Stack Web Development',
      provider: 'freeCodeCamp',
      hours: '300+',
      icon: BookOpen
    },
    {
      title: 'Machine Learning Specialization',
      provider: 'Coursera (Stanford)',
      hours: '150+',
      icon: Award
    },
    {
      title: 'Advanced React Patterns',
      provider: 'Epic React',
      hours: '80+',
      icon: BookOpen
    },
    {
      title: 'System Design Interview',
      provider: 'Educative',
      hours: '60+',
      icon: Users
    }
  ];

  return (
    <section id="education" className="py-20 bg-gradient-to-br from-indigo-50 to-purple-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-indigo-200 to-purple-200 rounded-full opacity-30 transform translate-x-40 -translate-y-40"></div>
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gradient-to-tr from-blue-200 to-indigo-200 rounded-full opacity-30 transform -translate-x-36 translate-y-36"></div>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-600 text-white rounded-full mb-6">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Education & <span className="text-indigo-600">Learning</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            My academic journey and continuous pursuit of knowledge in technology and development.
          </p>
        </motion.div>

        {/* Formal Education */}
        <div className="mb-20">
          <motion.h3
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-2xl font-bold text-gray-800 mb-8 text-center"
          >
            Formal Education
          </motion.h3>

          <div className="space-y-8">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl shadow-xl overflow-hidden"
              >
                <div className={`bg-gradient-to-r ${edu.color} p-6 text-white`}>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <h4 className="text-2xl font-bold mb-2">{edu.degree}</h4>
                      <p className="text-lg opacity-90">{edu.school}</p>
                      <p className="text-sm opacity-80">{edu.location}</p>
                    </div>
                    <div className="mt-4 md:mt-0 text-right">
                      <span className="px-4 py-2 bg-white/20 rounded-full text-sm font-medium">
                        {edu.period}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <p className="text-gray-600 mb-6 leading-relaxed">{edu.description}</p>
                  
                  <div>
                    <h5 className="font-semibold text-gray-800 mb-4">Key Achievements:</h5>
                    <div className="grid md:grid-cols-2 gap-3">
                      {edu.achievements.map((achievement, achIndex) => (
                        <motion.div
                          key={achIndex}
                          className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg"
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.5, delay: achIndex * 0.1 }}
                          viewport={{ once: true }}
                        >
                          <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                          <span className="text-gray-700 text-sm">{achievement}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="mb-20">
          <motion.h3
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-2xl font-bold text-gray-800 mb-8 text-center"
          >
            Professional Certifications
          </motion.h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300"
              >
                <div className={`w-16 h-16 ${cert.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-bold text-gray-800 mb-2">{cert.title}</h4>
                <p className="text-gray-600 text-sm mb-2">{cert.issuer}</p>
                <p className="text-gray-500 text-xs mb-3">{cert.date}</p>
                <p className="text-xs text-gray-400 font-mono">{cert.credentialId}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Additional Learning */}
        <div>
          <motion.h3
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-2xl font-bold text-gray-800 mb-8 text-center"
          >
            Continuous Learning
          </motion.h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {additionalLearning.map((course, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg mb-4">
                  <course.icon className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-bold text-gray-800 mb-2">{course.title}</h4>
                <p className="text-gray-600 text-sm mb-2">{course.provider}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">{course.hours} hours</span>
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Learning Philosophy */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">My Learning Philosophy</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Never Stop Learning</h4>
                <p className="text-gray-600 text-sm">Technology evolves rapidly, and staying curious and continuously learning is essential for growth.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Learn by Teaching</h4>
                <p className="text-gray-600 text-sm">Sharing knowledge with others helps deepen understanding and contributes to the community.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Practice Makes Perfect</h4>
                <p className="text-gray-600 text-sm">Hands-on experience and building real projects is the best way to master new skills.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Education;